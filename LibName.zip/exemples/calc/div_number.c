
#include "LibName.h"

int main(){
    double r = div_number(10,20);
    printf("%lf",r);
}