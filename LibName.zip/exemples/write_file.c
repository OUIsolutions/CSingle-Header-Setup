
#include "LibName.h"

int main(){
   write_file("side_effect/b.txt","my Menssage 2\n");
    
}