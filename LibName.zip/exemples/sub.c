
#include "LibName.h"

int main(){
    double r = sub(10,20);
    printf("%lf",r);
}