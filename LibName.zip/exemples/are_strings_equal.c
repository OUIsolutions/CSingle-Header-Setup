
#include "LibName.h"

int main(){
    bool result = are_strings_equal("test","test");
    printf("%d",result);
}