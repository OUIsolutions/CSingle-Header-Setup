


## ------------------------ Tests -----------------------------------------------
TEST_FOLDER = 'tests'
#if your project alterate something (write/modify) , make that changes
# into the side effect folder,it will be reconstructed on every tests
SIDE_EFFECT_FOLDER = 'side_effect'
#the final name of your lib
#if its set to true , it will reconstruct all the given tests
RECONSTRUCT = False

#-----------------------------Lib---------------------------------------------------
STARTER = 'src/start.h'
OUTPUT = 'LibName.h'
#These its the name of the output zip of your lib
ZIP_NAME ='LibName'
USE_VALGRIND = True


