

STARTER = 'src/start.h'
TEST_FOLDER = 'tests'
SIDE_EFFECT_FOLDER = 'side_effect'
#the final name of your lib
OUTPUT = 'LibName.h'

#These its the name of the output zip of your lib
ZIP_NAME ='LibName'
USE_VALGRIND = True

#if its set to true , it will reconstruct all the given tests
RECONSTRUCT = False
