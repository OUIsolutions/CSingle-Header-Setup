
#include "../../../LibName.h"

int main(){
    double r = mull(10,20);
    printf("%lf",r);
}