
#include "../../../LibName.h"

int main(){
    double r = add(10,20);
    printf("%lf",r);
}