

double add(double a, double b);

double sub(double a, double b);

double mull(double a, double b);

double div_number(double a, double b);