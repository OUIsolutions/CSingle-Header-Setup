

double add(double a, double b){
    return a + b;
}

double sub(double a, double b){
    return a - b;
}

double mull(double a, double b){
    return a *b;
}

double div_number(double a, double b){
    return a /b;
}
