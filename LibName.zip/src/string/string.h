

bool are_strings_equal(const char *a, const char *b);


char * join_strings(const char *a, const char *b);

