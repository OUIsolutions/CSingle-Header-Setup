

void write_file(const char *path, const char *content);

char *read_file(const char *fileName);
