# CSingle-Header-Setup
An Initial Template for Single Header Libs
